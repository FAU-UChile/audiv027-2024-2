// Variable (Iniciamos con ese valor: Screen1)
var mode = 1;

// Classifier Variable
let classifier;

// Model URL
let imageModelURL = "./my_model/";

// Variable de tiempo
let t = 0;

// Asignamos colores para cada etiqueta (label)
let colors = {
  ROJO: "red",
  AMARILLO: "yellow",
  AZUL: "blue",
};

// Declaramos variable label
let label = "";

// let space = {
//  'ROJO': 15,
//  'AMARILLO': 20,
//  'AZUL': 25,
//};

// Agregar Video
let video;
let flippedVideo;

// Cargamos el modelo entrenado en Teachable Machine
function preload() {
  classifier = ml5.imageClassifier(imageModelURL + "model.json");
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  // Create the video
  video = createCapture(VIDEO);
  video.size(windowWidth / 2, windowHeight / 2);
  video.hide();
  noStroke();

  // Comienza classifying
  classifyVideo();
}

function draw() {
  // Codigo que permite intercambiar entre dos modos (dos pantallas)
  if (mode == 0) {
    screen1();
  } else if (mode == 1) {
    screen2();
  }

  // Codigo de lo que se muestra en screen1
  function screen1() {
    background(0);
    // Draw the video
    imageMode(CENTER);
    image(video, windowWidth / 2, windowHeight / 2);

    // Escribir label en pantalla (Nombre del color)
    fill(0);
    textSize(32);
    textAlign(CENTER);
    text(label, windowWidth / 2, windowHeight / 3);
  }

  // Codigo de lo que se muestra en screen2
  function screen2() {
    background(0, 10); // translucent background (creates trails)

    // Determinar el color según la etiqueta
    let currentColor = colors[label] || "white"; // Color predeterminado a blanco si no hay etiqueta válida

    //   let currentCurve = space[label] || 15;

    // crear una grilla de círculos de x & y
    for (let x = 0; x <= width; x += 30) {
      for (let y = 0; y <= height; y += 30) {
        const xAngle = map(45, 0, width, -4 * PI, 4 * PI, true);
        const yAngle = map(90, height, -4 * PI, 4 * PI, true);
        const angle = xAngle * (x / width) + yAngle * (y / height);

        const myX = x + 20 * cos(2 * PI * t + angle);
        const myY = y + 20 * sin(2 * PI * t + angle);

        // Cambiar el color de relleno
        fill(currentColor);

        // Dibujar círculo
        ellipse(myX, myY, 10);
      }
    }

    // Actualizar tiempo
    t += 0.01;
  }
}

// Recibir predicción para imagen de video
function classifyVideo() {
  flippedVideo = ml5.flipImage(video);
  classifier.classify(flippedVideo, gotResult);
  flippedVideo.remove();
}

// Cuando recibimos resultado
function gotResult(error, results) {
  // Si hay un error
  if (error) {
    console.error(error);
    return;
  }
  // Resultados son ordenados por orden de confianza
  label = results[0].label;

  classifyVideo();
}

// Función para cambiar de pantallas al apretar el teclado
function keyPressed() {
  mode = mode + 1;
  if (mode == 2) {
    mode = 0;
  }
}
