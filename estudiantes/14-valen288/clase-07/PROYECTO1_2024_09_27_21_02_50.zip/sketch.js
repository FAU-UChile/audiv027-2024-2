// Classifier Variable
let classifier;
// Model URL
let imageModelURL = "./my_model/";

let t = 0; // time variable

// Colores para cada etiqueta
let colors = {
  'red': 'red',
  'yellow': 'yellow',
  'blue': 'blue'
};

// Video
let video;
let flippedVideo;
// To store the classification
let label = "";

// Load the model first
function preload() {
  classifier = ml5.imageClassifier(imageModelURL + "model.json");
}

function setup() {
  createCanvas(800, 600);
  // Create the video
  video = createCapture(VIDEO);
  video.size(640, 440);
  video.hide();
  noStroke();

  // Start classifying
  classifyVideo();
}

function draw() {
  background(0);
  // Draw the video
  //image(video, 0, 0);

  // Draw the label
  fill(255);
  textSize(16);
  textAlign(CENTER);
  text(label, 640 / 2, 460 - 4);
  
  background(10, 10); // translucent background (creates trails)

  // Determinar el color según la etiqueta
  let currentColor = colors[label] || 'white'; // Color predeterminado a blanco si no hay etiqueta válida

  // make a x and y grid of ellipses
  for (let x = 0; x <= width; x += 30) {
    for (let y = 0; y <= height; y += 30) {
      const xAngle = map(mouseX, 0, width, -4 * PI, 4 * PI, true);
      const yAngle = map(mouseY, 0, height, -4 * PI, 4 * PI, true);
      const angle = xAngle * (x / width) + yAngle * (y / height);

      const myX = x + 20 * cos(2 * PI * t + angle);
      const myY = y + 20 * sin(2 * PI * t + angle);

      fill(currentColor); // Cambiar el color de relleno
      ellipse(myX, myY, 10); // draw particle
    }
  }

  t += 0.01; // update time
}

// Get a prediction for the current video frame
function classifyVideo() {
  flippedVideo = ml5.flipImage(video);
  classifier.classify(flippedVideo, gotResult);
  flippedVideo.remove();
}

// When we get a result
function gotResult(error, results) {
  // If there is an error
  if (error) {
    console.error(error);
    return;
  }
  // The results are in an array ordered by confidence.
  label = results[0].label;
  // Classify again!
  classifyVideo();
}
